int main()
{
	int a; // integer variable
	float b; /* float variable */
	/* Multiline
	Comment */
	fun(); // function call
}