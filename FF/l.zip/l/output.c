int main()
{
int a; float b; 

fun(); 
}